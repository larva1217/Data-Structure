
interface Queue<E>{
	boolean isEmpty();
	void enqueue(E x);
	E dequeue();
	E peek();
}

class Node<E>{
	Object data;
	Node link;
	public Node(Object x) {
		data=x;
		link=null;
	}
}

class LinkQueue<E> implements Queue<E>{
	Node front, rear;
	int qSize;
	public LinkQueue(){
		front=rear=null;
		qSize=0;
	}
	public boolean isEmpty() {
//		if(front==null) {
//			return true;
//		}
//		else {
//			return false;
//		}
		return (front==null);
	}
	public void enqueue(E x) {
		Node<E> newNode = new Node<>(x);
		if(isEmpty()) {
			front=newNode;
			rear=newNode;
		}else {
			rear.link=newNode;
			rear=newNode;
		}
		qSize++;
	}
	public E dequeue() {
		if(isEmpty()) {
			return null;
		}else {
			Object tmpItem=front.data;
			front=front.link;
			qSize--;
			return (E)tmpItem;
		}
	}
	public E peek() {
		if(front==null) {
			return null;
		}
		return (E)front.data;
	}
}

public class ListQGeneric {
	public static void main(String[] args) {
		System.out.println("Hello Java");
		LinkQueue<Integer> lq1 = new LinkQueue<>();
		lq1.enqueue(10);
		lq1.enqueue(20);
		System.out.println(lq1.dequeue());
		System.out.println(lq1.dequeue());
		System.out.println(lq1.peek());
	}
	
}
