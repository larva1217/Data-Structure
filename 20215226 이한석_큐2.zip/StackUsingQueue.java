import java.util.Queue;

import java.util.LinkedList;



class Stack<E>{

	Queue<E> q = new LinkedList<>();

	public void push(E x) {//원소추가

		q.add(x);

}

public E pop() {//마지막 원소 끄집어내기

	int size = q.size();

	for(int i = 0; i<size-1; i++) {

		q.add(q.remove());

	}

	return q.remove();

}

public E peek() {//마지막 원소 확인

	int size = q.size();

	for(int i = 0; i<size-1; i++) {

		q.add(q.remove());

	}

	return q.peek();

}

public boolean isEmpty() {//스택이 비어있는지

	return q.isEmpty();

	}

}



public class StackUsingQueue {

	public static void main(String[] args) {

		System.out.println("hello");

		Stack<Integer> s1 = new Stack<>();


		s1.push(1);

		s1.push(2);

		s1.push(3);

		s1.push(4);
		s1.push(5);
		s1.push(6);

		s1.push(7);

		s1.push(8);

		System.out.println(s1.pop());//8

		System.out.println(s1.peek());//7

		System.out.println(s1.pop());//7

		System.out.println(s1.pop());//6

		System.out.println(s1.peek());//5

		System.out.println("is s1 Empty? : "+ s1.isEmpty());

	}



}