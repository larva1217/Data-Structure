package week12;
import java.util.*;

public class StringQ {
	public static void main(String[] args) {
		StringQ q = new StringQ();
		q.add("abcdefghijkl");
		q.print();
	}
}

class StringQ {
	Queue q1 = new LinkedList();
	Queue q2 = new LinkedList();
	public void add(String s) {
		for(int i=0;i<s.length(); if(i%2==0) {
			q1.add(s.charAt(i));
		}
		else {
			q2.add(s.charAt(i));
		}
	}
}

public void print() {
	while(!q1.isEmpty()) {
		System.out.print(q1.poll() + " ");
	}
	System.out.println();
	while(!q2.isEmpty()) {
		System.out.print(q2.poll() + " ");
	}
	System.out.println();
	}
}
