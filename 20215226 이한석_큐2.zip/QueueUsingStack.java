
import java.util.Stack;
class Queue<E>{
	Stack<E> s1 = new Stack<>();
	Stack<E> tmpS = new Stack<>();
	public void enqueue(E x) {
		s1.push(x);
	}
	public E dequeue() {
		if(s1.isEmpty()) {
			return null;
		}
		while(!s1.isEmpty()) {
			tmpS.push(s1.pop());
		}
		E x = tmpS.pop();
		while(!tmpS.isEmpty()) {
			s1.push(tmpS.pop());
		}
		return x;
	}
	public boolean isEmpty() {
		return s1.isEmpty();
	}
}
public class QueueUsingStack {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello Java");
		Queue<Integer> q1 = new Queue<>();
		
	}

}
