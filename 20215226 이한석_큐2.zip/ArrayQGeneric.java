

interface Queue<E>{
	boolean isEmpty();
	void enqueue(E x);
	E dequeue();
	E peek();
}

class ArrayQueue<E> implements Queue<E>{
	Object[] q;
	int front, rear, qSize;
	public ArrayQueue() {
		q=new Object[10];
		front=0;
		rear=0; 
		qSize=0;
	}
	public boolean isEmpty() {
		return front==rear;
	}
	public void enqueue(E x) {
		if((rear+1)%q.length==front) {
			reSizeQ(q.length*2);
		}
		rear=(rear+1)%q.length;
		q[rear]=x;
		qSize++;
	}
	public void reSizeQ(int newSize) {
		Object[] tmpQ = new Object[newSize];
		for(int i=1, j=front+1; i<qSize+1; i++,j++) {
			tmpQ[i]=q[j%q.length];
		}
		front=0; 
		rear=qSize;
		q=tmpQ;
	}
	public E dequeue() {
		Object tmpItem;
		if(isEmpty()) { return null; }
		front=(front+1)%q.length;
		tmpItem=q[front];
		q[front]=null;
		qSize--;
		return (E)tmpItem;
	}
	public E peek() {
		return (E)q[(front+1)%q.length];
	}
}

public class ArrayQGeneric {
	public static void main(String[] args) {
		System.out.println("Hello Java");
		ArrayQueue<Integer> aq1 = new ArrayQueue<>();
		aq1.enqueue(10);
		aq1.enqueue(20);
		System.out.println(aq1.dequeue());
		System.out.println(aq1.peek());
	}
	
}

