package week07;
import java.util.LinkedList;
public class LinkedListUtil {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0;
		double avg=0;
		LinkedList<Integer> score= new LinkedList<Integer>();
		score.add(80);
		score.add(95);
		score.add(72);
		score.add(83);
		score.add(57);
		
		System.out.print("score = ");
		for(int i : score) {
			System.out.print(i + " ");
		}
		System.out.println();
		
		for(int i : score) {
			sum += i;
		}
		avg = sum/score.size();
		System.out.println("평균 : " + avg);
	}

}
