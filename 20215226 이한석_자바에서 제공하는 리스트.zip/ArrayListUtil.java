package week07;
import java.util.ArrayList;
public class ArrayListUtil {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> list1 = new ArrayList<String>();
		list1.add("Choi");
		list1.add("Kim");
		list1.add("Lee");
		list1.add("Park");
		list1.add("Yoo");
		
		for(String name : list1) {
			System.out.print(name + " ");
		}
		System.out.println();
		System.out.println("리스트의 첫번쨰 원소 : " + list1.get(0));
		System.out.println("리스트의 마지막 원소 : " + list1.get(list1.size()-1));
		int middleIndex = list1.size()/2;
		System.out.println("리스트의 중간 원소 : " + list1.get(middleIndex));
		System.out.println("리스트의 원소의 개수 : " + list1.size());
		
		ArrayList<String> list2 = new ArrayList<String>();
		list2.add("Moon");
		list2.add("Song");
		list2.add("Seo");
		list2.add("Jeong");
		
		list1.addAll(list2);
		System.out.print("두 리스트 합병 : ");
		for(String name : list1) {
			System.out.print(name + " ");
		}
		
	}

}
