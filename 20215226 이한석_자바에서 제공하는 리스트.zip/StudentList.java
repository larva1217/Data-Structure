package week07;
import java.util.ArrayList;

class Student{
	Integer id;
	String name;
	public Student(int i, String n) {
		id=i;
		name=n;
	}
	public void print() {
		System.out.print(id + " " + name + " ");
	}
}

public class StudentList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Student> list3 = new ArrayList<Student>();
		list3.add(new Student(1,"Kim"));
		list3.add(new Student(3,"Lee"));
		list3.add(new Student(2,"Choi"));
		
		for(int i=0; i<list3.size(); i++) {
			list3.get(i).print();
		}
	}

}
