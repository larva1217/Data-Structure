
import java.util.Stack;
public class InfixToPostfixMain {
	
	public static int Prec(char ch) {
		if((ch=='+')||(ch=='-')) { return 1; }
		if((ch=='*')||(ch=='/')) { return 2; }
		if(ch=='^') { return 3; }
		return 1;
	}
	public static String infixToPostfix(String exp) {
		String result="";
		Stack<Character> stack1 = new Stack<>();
		for(int i=0; i<exp.length(); i++) {
			char c = exp.charAt(i);
			if(Character.isLetterOrDigit(c)) {
				result = result + c;
			}else if(c=='(') {
				stack1.push(c);
			}else if(c==')') {
				while((!stack1.isEmpty())&&(stack1.peek()!='(')) {
					result=result+stack1.pop();
				}
				stack1.pop();
			}else {
				while((!stack1.isEmpty())&&Prec(c)<=Prec(stack1.peek())) {
					result=result+stack1.pop();
				}
				stack1.push(c);
			}
		}
		return result;
	}
	public static void main(String[] args) {
		String exp="a+b*(c^d-e)^(f+g*h)-i";
		System.out.println(infixToPostfix(exp));
	}
}
