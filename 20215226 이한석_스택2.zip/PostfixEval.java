
import java.util.Stack;

class PostFixStack{
	public static int cal(String exp) {
		Stack<Integer> stack1 = new Stack<>();
		for(int i=0; i<exp.length(); i++) {
			char c = exp.charAt(i);
			if(Character.isDigit(c)) {
				stack1.push(c-'0');
				int a = Character.getNumericValue(c);
				stack1.push(a);
			}else {
				int a = stack1.pop();
				int b = stack1.pop();
				switch(c) {
					case '+' : stack1.push(a+b);
						break;
					case '-' : stack1.push(b-a);
				}
			}
		}
		
		return 10;
	}
}
public class PostfixEval {
	public static void main(String[] args) {
		String exp = "231+*9-";
		System.out.println(PostFixStack.cal(exp));
	}
}
