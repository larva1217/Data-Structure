


interface Stack<T> {
    boolean isEmpty();
    void push(T x);
    T pop();
    T peek();
}

class Student {
    int id;
    String name;

    public Student(int id, String name) {
        this.id = id;
        this.name = name;
    }
}

class ArrayStack<T> implements Stack<T> {
    private int top;
    private Object[] itemArray;
    private int stackSize;

    public ArrayStack() {
        stackSize = 100;
        itemArray = new Object[stackSize];
        top = -1;
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public void push(T x) {
        if (top == stackSize - 1) {
            stackFull();
        }
        top++;
        itemArray[top] = x;
    }

    private void stackFull() {
        int newSize = stackSize * 2;
        Object[] newArray = new Object[newSize];
        System.arraycopy(itemArray, 0, newArray, 0, stackSize);
        stackSize = newSize;
        itemArray = newArray;
    }

    public T pop() {
        if (isEmpty()) {
            return null;
        }
        T poppedItem = (T) itemArray[top];
        top--;
        return poppedItem;
    }

    public T peek() {
        if (isEmpty()) {
            return null;
        }
        return (T) itemArray[top];
    }
}

public class GenericArrayStackMain {
    public static void main(String[] args) {
        ArrayStack<String> stack1 = new ArrayStack<>();
        stack1.push("Kim");
        stack1.push("Lee");
        stack1.push("Park");
        stack1.push("Song");
        System.out.println("peek: " + stack1.peek());
        System.out.println(stack1.pop());
        System.out.println(stack1.pop());
        System.out.println(stack1.pop());
        System.out.println(stack1.pop());
        System.out.println(stack1.pop());

        ArrayStack<Student> stack3 = new ArrayStack<>();
        Student s1 = new Student(1, "Kim");
        stack3.push(s1);
        Student s2 = new Student(2, "Lee");
        stack3.push(s2);
        Student s3 = new Student(3, "Park");
        stack3.push(s3);
        Student s4 = new Student(4, "Choi");
        stack3.push(s4);
        Student s5 = new Student(5, "Yoo");
        stack3.push(s5);
        Student s6 = new Student(6, "Jang");
        stack3.push(s6);
        Student s7 = new Student(7, "Joo");
        stack3.push(s7);
        Student s8 = new Student(8, "Lim");
        stack3.push(s8);
        Student s9 = new Student(9, "Yong");
        stack3.push(s9);
        Student s10 = new Student(10, "Jae");
        stack3.push(s10);

        Student topStudent = stack3.peek();
        System.out.println("Top student: ID=" + topStudent.id + ", Name=" + topStudent.name);
    }
}
