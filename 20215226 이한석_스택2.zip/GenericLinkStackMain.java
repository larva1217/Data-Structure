

interface Stack<E> {
	boolean isEmpty(); 

	public abstract void push(Object x);

	public abstract E pop();

	void remove();

	E peek();
}
class Node<E> {
	Object data;
	Node link;
	public Node(Object x) {
		data=x;
		link=null;
	}
}
class Student {
	int id;
	String name;
	Student link;
	public Student(int x, String y) {
		id=x;
		name=y;
		link=null;
	}
	public String toString() {
		return "id = " + id + ", name = " + name;
	}
}
class LinkStack<E> {
	public Node<E> top; 
	public boolean isEmpty() {
//			if (top==null) { return true;}
//			else { return false;}
		return (top==null);
	};
	public void push(Object x) {//insertFirst
		Node newNode = new Node(x);
		newNode.link=top;
		top=newNode;
	}
	public E pop() { // deleteFirst
		if (isEmpty()) {
			return null;
		}else {
			Object item=top.data;
			top=top.link;
			return (E)item;
		}
	}
	public E peek() {
		if (isEmpty()) {
			return null;
		}else {
			return (E)top.data;
		}
	}
	public void remove() {
	};
}
public class GenericLinkStackMain {

	
	public static void main(String[] args) {
//		System.out.println("Hello Java\n");
		LinkStack<String> stack1 = new LinkStack<String>();
		stack1.push("Park");
		stack1.push("Lee");
		stack1.push("Kim");
		System.out.println(stack1.peek());
		System.out.println(stack1.pop());
		System.out.println(stack1.pop());
		System.out.println(stack1.pop());
		System.out.println(stack1.pop());	//비었을때는 null
		
		System.out.println();
		
		LinkStack<Integer> stack2 = new LinkStack<Integer>();
		stack2.push(10);
		stack2.push(20);
		System.out.println(stack2.peek());
		System.out.println(stack2.pop());
		System.out.println(stack2.pop());
		
		System.out.println();
		
		LinkStack<Student> stack3 = new LinkStack<Student>();
		stack3.push(new Student(1, "Kim"));
		stack3.push(new Student(2, "Lee"));
		stack3.push(new Student(3, "Park"));
		stack3.push(new Student(4, "Yoo"));
		stack3.push(new Student(5, "qwe"));
		stack3.push(new Student(6, "asd"));
		stack3.push(new Student(7, "zxc"));
		stack3.push(new Student(8, "pizza"));
		stack3.push(new Student(9, "coke"));
		stack3.push(new Student(0, "sushi"));
		
		while(stack3.peek() != null) {
			System.out.println(stack3.pop());
		}
	}
}