
import java.util.Stack; 

public class MyStringCheck {
	public static boolean checkString (String s) {
		char[] s2 = s.toCharArray();
		Stack<Character> stack1 = new Stack<>();
		Stack<Character> stack2 = new Stack<>();
		Stack<Character> stack3 = new Stack<>();
		
		int i; 
		for(i=0; i<  s2.length && s2[i] == 'a'; i++) {
			stack1.push(s2[i]);
		}
		int j;
		for(j=i; j <  s2.length && s2[j] == 'b'; j++) {
			stack2.push(s2[j]);
		}
		int k;
		for(k=j; k < s2.length; k++) {
			stack3.push(s2[k]);
		}
		
		 try {
	            while (!stack1.isEmpty() && !stack2.isEmpty() && !stack3.isEmpty()) {
	                stack1.pop();
	                stack2.pop();
	                stack2.pop();
	                stack3.pop();
	            }
	        } catch (Exception e) {
	            return false; 
	        }

	      
	        return stack1.isEmpty() && stack2.isEmpty() && stack3.isEmpty();
		 
	}
	public static void main(String[] args) {
		String s1 = "aabbbbcc";
		String s2 = "aabbcc";
		String s3 = "aaabbbbbbccc";
		System.out.println("result = " + checkString(s1));
		System.out.println("result2 = " + checkString(s2));
		System.out.println("result3 = " + checkString(s3));

	}

}
