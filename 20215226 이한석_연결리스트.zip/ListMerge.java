
class Node {
	int id;
	Node link;

	public Node(int id1) {
		id = id1;
	}
}

public class ListMerge {

	public static void main(String[] args) {
		System.out.println("Hello Java");
		Node list1 = new Node(10);
		Node last = list1;
		Node tmpNode;
		Node p1, p2;
		Node list3;
		last.link = new Node(40);
		last = last.link;
		last.link = new Node(100);
		last = last.link;
		last.link = new Node(122);
		last = last.link;
		Node list2 = new Node(15);

		last = list2;
		last.link = new Node(30);
		last = last.link;
		last.link = new Node(80);
		last = last.link;
		last.link = new Node(150);
		last = last.link;
		last.link = new Node(200);
		last = last.link;
		p1 = list1;
		p2 = list2;
		list3 = null;
		last = null;
		int count = 0;
		while ((p1 != null) && (p2 != null)) {
			if (p1.id <= p2.id) {
				if (count == 0) {
					count++;
					list3 = new Node(p1.id);
					last = list3;
				} else {
					last.link = new Node(p1.id);
					last = last.link;
				}
				p1 = p1.link;
			} else {
				if (count == 0) {
					count++;
					list3 = new Node(p2.id);
					last = list3;
				} else {
					last.link = new Node(p2.id);
					last = last.link;
				}
				p2 = p2.link;
			}
		}
		if(p1!=null) {
			while(p1!=null) {
				System.out.println(" "+p1.id);
				last.link = new Node(p1.id);
				last = last.link;
				p1=p1.link;
			}	
		}else {
			while(p2!=null) {
				System.out.println(" "+p2.id);
				last.link = new Node(p2.id);
				last = last.link;
				p2=p2.link;
			}	
		}
		for (tmpNode = list3; tmpNode != null; tmpNode = tmpNode.link) {
			System.out.print(" " + tmpNode.id);
		}
		System.out.println("end of merge");
	}
}
