class Node {
	String data;
	Node link;
	public Node(String data1) {
		data = data1;
		link = null;
	}
}
public class LinkedListBasic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Node list1;
		Node tail;
		Node p;
		Node tmp2;
		Node tmpNode;
		int k=0;
		int count=0;
		
		tail = new Node("Apple");
		list1 = tail;
		tail.link = new Node("Strawberry");
		tail=tail.link;
		tail.link = new Node("Orange");
		tail=tail.link;
		tail.link = new Node("Banana");
		tail=tail.link;
		tail.link = new Node("Melon");
		tail=tail.link;
		tmpNode= new Node("Pineapple");
		tmpNode.link=list1;
		list1=tmpNode;
		p=list1;
		while (p!=null) {
			count++;
			//System.out.println(" "+count);
			System.out.print(" "+p.data);
			p=p.link;
		}
		System.out.println();
		k=2;
		count=0;
		p=list1;
		while(p!=null) {
			count++;
			if((k-1) ==count) {
				p.link=p.link.link;
			}
			System.out.print(" "+p.data);
			p=p.link;
		}
		
		while (p!=null) {
			count++;
			//System.out.println(" "+count);
			System.out.print(" "+p.data);
			p=p.link;
		}
		System.out.println();
		System.out.println("원소의 개수: " +count);
		  	 tmp2 = new Node("Dulian"); //5
	         tail.link = tmp2;
	         
	         p = list1;
	         while (p != null) {
	            System.out.print(" " + p.data);
	            p = p.link;
	         }
	         System.out.println("");
	         Node newNode = new Node("Tomato");

	         // 새로운 노드를 추가할 위치의 이전 노드 찾기 (3번째 노드)
	         Node prevNode = list1;
	         for (int i = 1; i < 3; i++) {
	             prevNode = prevNode.link;
	         }
	         // 3번째 노드 뒤에 새로운 노드를 추가
	          newNode.link = prevNode.link; //이전 노드의 링크에 새로운 노드의 링크를 연결
	         prevNode.link = newNode; //새로운 노드가 추가된 기존의 노드에 "토마토"라는 값 추가

	         // 전체 리스트 출력
	         p = list1;
	         while (p != null) {
	             System.out.print(" " + p.data);
	             p = p.link;
	         }
	         System.out.println();
	}
}

	

