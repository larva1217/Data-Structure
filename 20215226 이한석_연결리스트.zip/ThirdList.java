
class Node{
	String name;
	Node next;
	
	public Node(String name1) {
		name = name1;
		next = null;
	}
}
public class ThirdList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Node list1;
		Node tail;
		int count=0;
		tail = new Node("Choi");
		list1 = tail;
		list1.next=new Node("Kim");
		list1.next.next=new Node("Lee");
		list1.next.next.next=new Node("Park");
		list1.next.next.next.next=new Node("Yoo");
		
		Node p=list1;
		while(p.next!=null) {
			System.out.print(p.name+" ");
			count+=1;
			if(count==4) {
				System.out.println("\nlinkList1의 네번째 원소 "+p.name);				
			}
			p=p.next;
		}
		String []arrList1=new String[]{"Choi","Kim","Lee","Park","Yoo"};
		for(String data:arrList1) {
			System.out.print(data+" ");
		}
		System.out.println("\narrList1의 네번째 원소 "+arrList1[3]);
		
	}
}


