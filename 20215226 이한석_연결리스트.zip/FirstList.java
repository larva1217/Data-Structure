

class ListNode{
	String name;
	ListNode link;
	public ListNode(String name1) {
		name=name1;
		link=null;
	}
}
public class FirstList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ListNode list1 = new ListNode("Kim");
		list1.link = new ListNode("Lee");
		list1.link.link = new ListNode("Park");
		list1.link.link.link = new ListNode("YOO");
		System.out.println(list1.name);
		System.out.println(list1.link.name);
		System.out.println(list1.link.link.name);
		System.out.println(list1.link.link.link.name);
	}

}
