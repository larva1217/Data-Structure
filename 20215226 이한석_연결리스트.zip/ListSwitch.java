

public class ListSwitch {
	public static void main(String[] args) {
		int x=3;
		int y=5;
		int tmp=0;
		tmp = x;
		x = y;
		y = tmp;
		System.out.println("x의 값 :" + x);
		System.out.println("y의 값 : " + y);
		
		int[] a={1,2,3,4};
		int[] b = {5,6,7,8,9};
		int[] tmp1;
		tmp1 = a;
		a = b;
		b = tmp1;
		System.out.print("a = [ ");
		for(int i=0; i<a.length; i++) {
			System.out.print(a[i]+" ");
		}
		System.out.println("]");
		System.out.print("b = [ ");
		for(int i=0; i<b.length; i++) {
			System.out.print(b[i]+" ");
		}
		System.out.println("]");
		
		
		
	}
} 
