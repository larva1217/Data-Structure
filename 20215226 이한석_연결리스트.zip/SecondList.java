
class ListNode1{
	String name;
	ListNode1 link;
	public ListNode1() {
		this.name = null;
		this.link = null;
	}
	public ListNode1(String name){
		this.name = name;
		this.link = null;
	}
}

public class SecondList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ListNode1 L = new ListNode1();
		L.link = new ListNode1("Cho");
		L.link.link = new ListNode1("Kim");
		L.link.link.link = new ListNode1("Lee");
		L.link.link.link.link = new ListNode1("Park");
		L.link.link.link.link.link = new ListNode1("Yoo");
		
		System.out.println(L.link.name);
		System.out.println(L.link.link.name);
		System.out.println(L.link.link.link.name);
		System.out.println(L.link.link.link.link.name);
		System.out.println(L.link.link.link.link.link.name);
	}

}
