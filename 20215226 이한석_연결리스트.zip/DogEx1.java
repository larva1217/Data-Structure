
class Dog{
	String name;
	int age;
	static int count=0;
	public Dog() {
		count++;
	}
	public Dog(String x) {
		count++;
		name = x;
	}
	public Dog(String x, int age) {
		count++;
		name = x;
		this.age = age;
	}
	static void printDog(Dog d) {
		System.out.println(d.name + " d.age");
	}
	static int countDog() {
		return count;
	}
}

public class DogEx1 {

	public static void main(String[] args) {
		System.out.println("Hello Java");
		Dog d1 = new Dog("Happy", 1);
		System.out.println(d1.name + " "+d1.age);
		Dog d2 = new Dog();
		d2.name="Honey";
		d2.age = 2;
		System.out.println(d2.name + " "+d2.age);
		Dog d3 = new Dog("Lucky", 3);
		Dog d4 = new Dog("Jeolmi", 4);
		Dog d5 = new Dog("Gom", 5);
		System.out.println(Dog.countDog());
		Dog tmpDog;
		tmpDog=d1;
		d1=d2;
		d2=tmpDog;
		Dog.printDog(d1);
		Dog.printDog(d2);

	}

}
