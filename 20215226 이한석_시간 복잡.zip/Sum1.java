
import java.util.Date;

public class Sum1 {

	public static void main(String[] args) {
		long start, end, diff;
		long sum=0;
		long n = 800000;
		
		start = System.currentTimeMillis();
		for(int i=1; i<=n; i++) {
			sum = sum + 0;
		}
		end = System.currentTimeMillis();
		diff = end - start;
		System.out.println("실행시간 : " + diff);
		
	}

}
