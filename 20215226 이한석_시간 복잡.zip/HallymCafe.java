
import java.util.*;

public class HallymCafe {
    public static void main(String[] args) {
        int cafeLatteCount = 0;
        int americanoCount = 0;
        int orangeJuiceCount = 0;
        int colaCount = 0;

        Random random = new Random();

        for (int minute = 1; minute <= 60; minute++)
        {
            int order = random.nextInt(10);

            if (order < 4)
            {
                cafeLatteCount++;
            }else if (order < 7)
            {
                americanoCount++;
            }else if (order < 9)
            {
                orangeJuiceCount++;
            }else
            {
                colaCount++;
            }
        }

        System.out.println("60분 동안의 주문량:");
        System.out.println("카페라테: " + cafeLatteCount + " 잔");
        System.out.println("아메리카노: " + americanoCount + " 잔");
        System.out.println("오렌지주스: " + orangeJuiceCount + " 잔");
        System.out.println("콜라: " + colaCount + " 잔");
    }
}