import java.util.Date;
public class Sum2 {

	public static void main(String[] args) {
		long start, end, diff;
		long sum=0;
		long n = 500000;
		
		start = System.currentTimeMillis();
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=n; j++) {
				sum = sum + n;
			}
		}
		end = System.currentTimeMillis();
		diff = end - start;
		System.out.println("실행시간 : " + diff);
	}

}
