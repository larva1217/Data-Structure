
class Node{
	String name;
	Node link;
	public Node(String name1) {
		name=name1;
		link=null;
	}
}
public class CLinkedListBasic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Node tail;
		Node p;
		Node tmpNode;
		
		tmpNode=new Node("Kim");
		tmpNode.link=tmpNode;
		tail=tmpNode;
		System.out.println(" "+tail.name);
		tmpNode=new Node("Lee");
		tmpNode.link=tail.link;
		tail.link=tmpNode;
		tail=tmpNode;
		tmpNode=new Node("Park");
		tmpNode.link=tail.link;
		tail.link=tmpNode;
		tail=tmpNode;
		tmpNode=new Node("Choi");
		tmpNode.link=tail.link;
		tail.link=tmpNode;
		tail=tmpNode;
		
		p=tail.link;
		while(p.link!=tail) {
			p=p.link;
		}
		p.link=p.link;
		tail=p;
		
		
		int count=0;
		p=tail.link;
		do {
			count++;
			System.out.print(" "+p.name);
			p=p.link;
		}while(p!=tail.link);
		System.out.println();
	}

}
