

class Node {
    String data;
    Node next;

    public Node(String data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    Node tail;

    public void addLast(String data) {
        Node newNode = new Node(data);
        if (tail == null) {
            tail = newNode;
            tail.next = newNode;
        } else {
            newNode.next = tail.next;
            tail.next = newNode;
            tail = newNode;
        }
    }

    public void printList() {
        if (tail == null) {
            System.out.println("리스트가 비어 있습니다.");
            return;
        }
        Node current = tail.next;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != tail.next);
        System.out.println();
    }
}

public class CLdays {
    public static void main(String[] args) {
        String[] days = {"월", "화", "수", "목", "금", "토", "일"};

        CircularLinkedList list = new CircularLinkedList();
        for (String day : days) {
            list.addLast(day);
        }

        System.out.println("원형 연결 리스트의 요일:");
        list.printList();
    }
}