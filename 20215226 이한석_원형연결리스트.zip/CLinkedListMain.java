

class Node{
	int data;
	Node next;
	public Node(int data1) {
		data=data1;
		next=null;
	}
}
class CList{
	Node tail;
	public void addFirst(int data1) {
		Node tmpNode = new Node(data1);
		if(tail==null) {
			tail=tmpNode;
			tmpNode.next=tmpNode;
		}else {
			tmpNode.next=tail.next;
			tail.next=tmpNode;
		}
	}
	public int deleteFirst() {
		int id;
		if(tail==null) {
			return -1;
		}
		if(tail==tail.next) {
			id=tail.data;
			tail=null;
			return id;
		}
		id=tail.next.data;
		Node p = tail.next;
		tail.next=p.next;
		return id;
	}
	public int deleteLast() {
		int id;
		Node p;
		if(tail==null) {
			return -1;
		}
		if(tail==tail.next) {
			id=tail.data;
			tail=null;
			return id;
		}
		id=tail.data;
		p=tail.next;
		while(p.next!=tail) {
			p=p.next;
		}
		p.next=tail.next;
		tail=p;
		return id;
	}
	public void printClist() {
		Node p;
		p=tail.next;
		do {
			System.out.print(" "+p.data);
			p=p.next;
		}while(p!=tail.next);
	}
	public int getNoofNode() {
	    if (tail == null) {
	        return 0;
	    }
	    int count = 0;
	    Node current = tail.next;
	    do {
	        count++;
	        current = current.next;
	    } while (current != tail.next);
	    return count;
	}
	
	public void addLast(int x) {
	    Node newNode = new Node(x);
	    if (tail == null) {
	        tail = newNode;
	        tail.next = newNode;
	    } else {
	        newNode.next = tail.next;
	        tail.next = newNode;
	        tail = newNode;
	    }
	}
	
	public boolean findData(int x) {
	    if (tail == null) {
	        return false;
	    }
	    Node current = tail.next;
	    do {
	        if (current.data == x) {
	            return true;
	        }
	        current = current.next;
	    } while (current != tail.next);
	    return false;
	}
	
	public void deleteNode(int x) {
	    if (tail == null) {
	        return;
	    }
	    if (tail == tail.next && tail.data == x) {
	        tail = null;
	        return;
	    }
	    Node current = tail.next;
	    Node prev = tail;
	    do {
	        if (current.data == x) {
	            prev.next = current.next;
	            if (current == tail) {
	                tail = prev;
	            }
	            return;
	        }
	        prev = current;
	        current = current.next;
	    } while (current != tail.next);
	}
}

public class CLinkedListMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CList clist1 = new CList();
		clist1.addFirst(10);
		clist1.addFirst(30);
		clist1.addFirst(40);
		clist1.addFirst(20);
		clist1.printClist();
		clist1.deleteFirst();
		System.out.println("선두원소 = " + clist1.deleteFirst()+" 삭제됨");
		System.out.println("마지막원소 = " + clist1.deleteLast()+" 삭제됨");
		System.out.println(clist1.getNoofNode());
		clist1.addLast(50);
		clist1.printClist();
		clist1.findData(30);
		clist1.deleteNode(30);
		clist1.printClist();
	}

}
