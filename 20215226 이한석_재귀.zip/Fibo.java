
class A{
	static long recursion(int n) {
		if(n<=1) {
			return 1;
		}
		else {
			return recursion(n-1) + recursion(n-2);
		}
	}
	
	static long iteration(int n) {
		int fn=0;
		int f1;
		int f2;
		if(n<=1){
			return 1;
		}
		else {
			f1 = 1;
			f2 = 1;
			for(int i=2; i<=n; i++) {
				fn = f1 + f2;
				f2 = f1;
				f1 = fn;
			}
			return fn;
		}
	}
}

public class Fibo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 10;
		System.out.println(A.recursion(n));
		System.out.println(A.iteration(n));
	}

}
