
public class BinSearch {
	static void decToBin(int num, int base) {
		if(num>0) {
			decToBin(num/base, base);
			System.out.println(num%base);
		}
	}
	
	static void decTobinIter(int num, int base){
		int[] arr=new int[10];
		int i=0;
		while (num>0) {
			arr[i]=num%base;
			i++;
			num=num/base;
		}
		for(int j=i-1;j>=0;j--) {
			System.out.print(arr[j]);
		}
		System.out.println();
	}


	public static void main(String[] args) {
		int decNo = 20;
		decToBin(decNo, 2);
		decTobinIter(decNo, 2);
		
	}

}
