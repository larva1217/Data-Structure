

class B{
	static long fac(int n) {
		if(n<=1) {
			return 1;
		}
		else {
			return n*fac(n-1);
		}
	}
	
	static long fact(int n) {
		int sum = 1;
		if(n<=1) {
			return 1;
		}
		else {
			for(int i=2; i<=n; i++) {
				sum = sum*i;
			}
			return sum;
		}
		
		
	}
}

public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 10;
		System.out.println(B.fac(n));
		System.out.println(B.fact(n));
	}

}
