import java.util.Scanner;

public class Armstrong {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Scanner 객체 생성
        System.out.println("수를 입력하세요 : ");
        int number = scanner.nextInt(); // 사용자로부터 정수 입력 받음
        int originalNumber = number;
        int sum = 0;

        while (number > 0) {
            int digit = number % 10; // 가장 낮은 자리 숫자 추출
            sum += Math.pow(digit, 3); // 각 자리 숫자의 세제곱을 더함
            number /= 10; // 다음 자리 숫자로 이동
        }

        if (sum == originalNumber) {
            System.out.println(originalNumber + "은(는) 암스트롱 수입니다.");
        } else {
            System.out.println(originalNumber + "은(는) 암스트롱 수가 아닙니다.");
        }
        
        scanner.close();
    }
}