class A1{
	int getSum() {
		int sum = 100 + 200;
		return sum;
	}
	
	int getAvg() {
		int avg = getSum()/2;
		return avg;
	}
}


public class Mymain {

	public static void main(String[] args) {
		A1 a1 = new A1();
		System.out.println(a1.getSum());
		System.out.println(a1.getAvg());

	}

}
