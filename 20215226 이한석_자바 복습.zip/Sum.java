
public class Sum {

	public static void main(String[] args) {
		int sum1 = 0;
		int n = 100;
		sum1 = n*(n+1)/2;
		System.out.println(sum1);
		
		int sum2=0;
		for(int i=1; i<=n; i++) {
			sum2 += i;
		}
		System.out.println(sum2);
		
		int sum3 = 0;
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=i; j++) {
				sum3 += 1; 
			}
		}
		System.out.println(sum3);
		
	}
}
