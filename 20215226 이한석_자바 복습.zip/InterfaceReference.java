interface Animal1{
	public static final String name = "동물";
	
	public abstract void eat();
	public abstract void bark();
}

class Cat implements Animal1{
	public void eat() {
		System.out.println("고양이 사료");
	}
	public void bark() {
		System.out.println("야옹");
	}
}

class Dog1 implements Animal1{
	public void eat() {
		System.out.println("개사료");
	}
	public void bark() {
		System.out.println("멍멍");
	}
}


public class InterfaceReference {

	public static void main(String[] args) {
		Cat c = new Cat();
		Dog1 d = new Dog1();
		
		d.bark();
		d.eat();
		System.out.println(d.name);
		c.bark();
		c.eat();
		System.out.println(c.name);

	}

}
