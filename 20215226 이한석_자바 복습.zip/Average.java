
public class Average {

	public static void main(String[] args) {
		int[] score;
		score = new int[10];
		score[0] = 98;
		score[1] = 77;
		score[2] = 65;
		score[3] = 84;
		score[4] = 52;
		score[5] = 60;
		score[6] = 30;
		score[7] = 20;
		score[8] = 10;
		score[9] = 100;
		
		int result = 0;
		for(int total=0; total<10; total++) {
			result += score[total];
		}
		
		int avg = result/10;
		System.out.println(avg);
	}

}
