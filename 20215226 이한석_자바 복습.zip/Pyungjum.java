
public class Pyungjum {

	public static void main(String[] args) {
		int I = 80;
		
		if(I>=90) {
			System.out.println("A");
		}else if(I>=80 && I<90) {
			System.out.println("B");
		}else if(I>=70 && I<80) {
			System.out.println("C");
		}else if(I>=60 && I<70) {
			System.out.println("D");
		}else {
			System.out.println("F");
		}

	}

}
