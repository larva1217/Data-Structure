
public class DoWhile {

	public static void main(String[] args) {
		int n = 1;
		System.out.println("*구구단 3단*");
		do {
			System.out.println(" " + 3 + "*" + n + "=" +(3*n));
			n++;
		}while(n<10);
	}

}
