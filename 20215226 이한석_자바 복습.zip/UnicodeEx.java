
public class UnicodeEx {

	public static void main(String[] args) {
		System.out.println((char) 65); 
		System.out.println((char) 0x41); 
		System.out.println((char) 0xAC00); 
		System.out.println((char) 0x91D1); 
		System.out.println((int) 'A'); 
		System.out.println(Integer.toHexString('A')); 
		System.out.println(Integer.toHexString('가')); 
		System.out.println(Integer.toHexString('金')); 
		
		System.out.println(Integer.toHexString('이')); 
		System.out.println(Integer.toHexString('한')); 
		System.out.println(Integer.toHexString('석')); 
		
		
		}

	}


