import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;

class customer_1 implements Comparable<customer_1> {
    int arrTime; // 입장 시간
    String name; // 이름
    int coffeeType; // 커피 종류 (1: 카페라테, 2: 아메리카노, 3: 오렌지주스, 4: 콜라)
    int prepTime; // 준비 시간

    public customer_1(int arrivalTime, String customer_1Name, int typeOfCoffee, int preparationTime) {
        arrTime = arrivalTime;
        name = customer_1Name;
        coffeeType = typeOfCoffee;
        prepTime = preparationTime;
    }

    @Override
    public int compareTo(customer_1 other) {
        // 준비 시간이 같은 경우, 입장 시간으로 비교
        if (this.prepTime == other.prepTime) {
            return Integer.compare(this.arrTime, other.arrTime);
        }
        return Integer.compare(this.prepTime, other.prepTime); // 준비 시간이 작은 순으로 우선순위
    }

    @Override
    public String toString() {
        String coffeeName = "";
        switch (coffeeType) {
            case 1: coffeeName = "카페라테"; break;
            case 2: coffeeName = "아메리카노"; break;
            case 3: coffeeName = "오렌지주스"; break;
            case 4: coffeeName = "콜라"; break;
        }
        return "손님 " + name + "이(가) " + arrTime + "분에 " + coffeeName + "를 주문하셨습니다.";
    }
}

public class HallymCafe_1 {
    public static void main(String[] args) {
        int curTime = 0; // 현재 시간 (분 단위)
        int cTime = 0;
        int latteCount = 0, americanoCount = 0, juiceCount = 0, colaCount = 0;
        String[] custName = {"Kim", "Lee", "Park", "Choi", "Hong", "Shin", "Yoo", "Son", "Cha", "Yoon"};
        int[] prepTimes = {5, 4, 2, 1}; // 준비 시간: 카페라테, 아메리카노, 오렌지주스, 콜라
        int customer_1Index = 0; int tempTime = -1;
        int count = 0; int sum = 0; int max = 0; int noWorkTime = 0;

        // 한림카페 우선순위 큐 (제조 시간이 짧은 순으로 처리)
        Queue<customer_1> hallymCafe = new PriorityQueue<>();
        Random rand = new Random();

        // 손님에게 9시부터 서비스 시작
        System.out.println("=====================");
        System.out.println("    서비스 시작");
        System.out.println("=====================");
        
        do {
        	int prepTime=0;
            if (rand.nextInt(10) < 3 && curTime<=60) { // 30% 확률로 손님 입장
                int randCoffee = rand.nextInt(100);
                int coffeeType;
                
                if (randCoffee < 40) {
                    coffeeType = 1;
                    prepTime = prepTimes[0];
                    latteCount++;
                } else if (randCoffee < 70) {
                    coffeeType = 2;
                    prepTime = prepTimes[1];
                    americanoCount++;
                } else if (randCoffee < 90) {
                    coffeeType = 3;
                    prepTime = prepTimes[2];
                    juiceCount++;
                } else {
                    coffeeType = 4;
                    prepTime = prepTimes[3];
                    colaCount++;
                }
                hallymCafe.add(new customer_1(curTime, custName[customer_1Index++], coffeeType, prepTime));
                if(customer_1Index >= custName.length) customer_1Index=0;
                
                count++;
            }
            curTime++;
            
            if(!hallymCafe.isEmpty() && tempTime < curTime) {
            	tempTime = curTime + prepTime;
            	customer_1 hcustomer_1 = hallymCafe.poll(); // 우선순위 큐에서 제거

                if (cTime < hcustomer_1.arrTime) { // 현재 시간이 손님 입장 시간보다 작다면
                	noWorkTime += hcustomer_1.arrTime - cTime; // 데이터
                    cTime = hcustomer_1.arrTime; // 현재 시간을 손님 도착 시간으로 조정
                }

                // 주문 처리 및 커피 제공
                System.out.println(hcustomer_1);
                cTime += hcustomer_1.prepTime; // 현재 시간 업데이트
                // 대기 시간 계산
                int waitTime = cTime - hcustomer_1.arrTime;
                System.out.println("==> " + (cTime % 60) + "분에 커피가 제공되었습니다. 대기 시간: " 
                		+ waitTime + "분\n");
                
                if(max<waitTime) max = waitTime;
                sum += waitTime;
            }
            
            
        }while(!hallymCafe.isEmpty() || curTime<=60);

        // 각 음료의 주문 수 출력
        System.out.println("=====================");
        System.out.println("    주문한 음료 수");
        System.out.println("=====================");
        System.out.println("카페라테: " + latteCount + "개");
        System.out.println("아메리카노: " + americanoCount + "개");
        System.out.println("오렌지주스: " + juiceCount + "개");
        System.out.println("콜라: " + colaCount + "개");
        
        System.out.println();
        
        System.out.println("한림카페에서 가장오래기다린 고객의 대기시간: " + max);
        System.out.println("고객의 평균 대기시간: " + (float)sum/count);
        System.out.println("직원이 서비스하지않고 대기한 시간: " + noWorkTime);
    }
}
