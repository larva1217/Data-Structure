
import java.util.Deque;
import java.util.ArrayDeque;

class Queue<E>{
	Deque<E> dq1 = new ArrayDeque<>();
	public void enqueue(E x) {
		dq1.addLast(x);
	}
	public E dequeue() {
		return dq1.removeFirst();
	}
	public E peek() {
		return dq1.peekFirst();
	}
	public boolean isEmpty() {
		return dq1.isEmpty();
	}
}

public class QueueUsingDQ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello Java");
		Queue<String> q1 = new Queue<>();
		q1.enqueue("Kim");
		q1.enqueue("Lee");
		q1.enqueue("Park");
		System.out.println(q1.peek());
		System.out.println(q1.dequeue());
		System.out.println(q1.isEmpty());
	}

}
