

class PQNode {
    String name;
    int priority;
    PQNode link;

    public PQNode(String name, int priority) {
        this.name = name;
        this.priority = priority;
        this.link = null;
    }

    @Override
    public String toString() {
        return name + " (Priority: " + priority + ")";
    }
}

class PriorityQqueue {
    PQNode front;

    public void enqueue(String name, int priority) {
        PQNode p, q;
        PQNode newNode = new PQNode(name, priority);
        if (front == null) {
            front = newNode;
        } else if (newNode.priority < front.priority) {
            newNode.link = front;
            front = newNode;
        } else {
            q = null;
            p = front;
            while (p != null && priority >= p.priority) {  
                q = p;
                p = p.link;
            }
            newNode.link = q.link;
            q.link = newNode;
        }
    }

    public PQNode dequeue() {
        if (front == null) {
            return null; // if the queue is empty
        }
        PQNode tmpNode = front;
        front = front.link;
        return tmpNode;
    }

    public PQNode peek() {
        return front;
    }

    public int size() {
        int count = 0;
        PQNode current = front;
        while (current != null) {
            count++;
            current = current.link;
        }
        return count;
    }
}

public class LinkPQ {
    public static void main(String[] args) {
        System.out.println("Hello Java");
        PriorityQqueue pq1 = new PriorityQqueue();
        pq1.enqueue("Kim", 30);
        pq1.enqueue("Lee", 20);
        pq1.enqueue("Park", 10);
        pq1.enqueue("Choi", 40);

        System.out.println(pq1.dequeue());
        System.out.println(pq1.size());
    }
}