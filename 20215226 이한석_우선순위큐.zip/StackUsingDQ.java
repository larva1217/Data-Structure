
import java.util.ArrayDeque;
import java.util.Deque;

class Stack<E>{
	Deque<E> dq1 = new ArrayDeque<>();
	public void push(E x) {
		dq1.addLast(x);
	}
	public E pop() {
		return dq1.removeFirst();
	}
	public E top() {
		return dq1.peekLast();
	}
	public boolean isEmpty() {
		return dq1.isEmpty();
	}
}

public class StackUsingDQ {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello Java");
		Stack<String> s1 = new Stack<>();
		s1.push("Kim");
		s1.push("Lee");
		s1.push("Park");
		System.out.println(s1.pop());
		System.out.println(s1.top());
		System.out.println(s1.isEmpty());
	}

}
