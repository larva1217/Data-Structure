
import java.util.PriorityQueue;
import java.util.Comparator;

class Student {
    int id;
    String name;
    int score;

    public Student(int id, String name, int score) {
        this.id = id;
        this.name = name;
        this.score = score;
    }

    @Override
    public String toString() {
        return "Student{id=" + id + ", name='" + name + "', score=" + score + "}";
    }
}

class StudentComparator implements Comparator<Student> {
    public int compare(Student x1, Student x2) {
        // Compare by score, higher score should come first
        return Integer.compare(x2.score, x1.score);
    }
}

public class PQComparator {
    public static void main(String[] args) {
        System.out.println("Hello Java");
        
        Comparator<Student> compStudent = new StudentComparator();
        PriorityQueue<Student> q = new PriorityQueue<>(compStudent);

        q.add(new Student(1, "Kim", 88));
        q.add(new Student(2, "Lee", 68));
        q.add(new Student(3, "Park", 88));
        q.add(new Student(4, "You", 55));
        q.add(new Student(5, "Choi", 99));

        System.out.println("Current size of priority queue: " + q.size());

        while (!q.isEmpty()) {
            Student tmps1 = q.remove();
            System.out.println("Removed: " + tmps1);
        }

        System.out.println("Current size of priority queue: " + q.size());
    }
}
