

import java.util.PriorityQueue;

class Student implements Comparable<Student> {
    int id;
    String name;
    int score;

    public Student(int id, String name, int score) {
        this.id = id;
        this.name = name;
        this.score = score;
    }

    public int compareTo(Student other) {
        return Integer.compare(other.score, this.score);
    }

    public String toString() {
        return "Student{id=" + id + ", name='" + name + "', score=" + score + "}";
    }
}

public class PQComparable {

    public static void main(String[] args) {
        System.out.println("Hello Java");
        PriorityQueue<Student> q = new PriorityQueue<>();

        q.add(new Student(1, "Kim", 88));
        q.add(new Student(2, "Lee", 68));
        q.add(new Student(3, "Park", 88));
        q.add(new Student(4, "You", 55));
        q.add(new Student(5, "Choi", 99));

        System.out.println(q.size());

        while (!q.isEmpty()) {
            Student tmps1 = q.remove();
            System.out.println(tmps1);
        }

        System.out.println(q.size());
    }
}
