
class PriorityQueue{
	int maxSize;
	int qArray[];
	int nItems;
	public PriorityQueue(int s) {
		maxSize=s;
		qArray = new int[maxSize];
		nItems=0;
	}
	public void insert(int x) {
		if(nItems==0) {
			qArray[0]=x;
			nItems++;
		}
		else if(nItems>=maxSize) {
			System.out.println("PQ is full");
			return;
		}
		else {
			int j=0; 
			for(j=nItems-1; j>=0; j--) {
				if(x>qArray[j]) {
					qArray[j+1]=qArray[j];
				}else {
					break;
				}
			}
			qArray[j+1]=x;
			nItems++;
		}
	}
	public int remove() {
		int x=qArray[nItems-1];
		nItems--;
		return x;
	}
	public int peek() {
		return qArray[nItems-1];
	}
	public boolean isEmpty() {
		return true;
	}
}

public class ArrayPQ {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello Java");
		PriorityQueue pq1 = new PriorityQueue(100);
		pq1.insert(20);
		pq1.insert(30);
		System.out.println(pq1.remove());
		System.out.println(pq1.nItems);
	}

}
