
public class LinerSearch {
	
	public static void search(int x[], int key) {
		int i;
		for(i=0; i<x.length; i++) {
			if(x[i] == key) {
				System.out.println(i);
			}else {
				System.out.println("없습니다.");
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr=new int[20];
		for(int i=0; i<20; i++) {
			arr[i] = (int)Math.random()*20+1;
		}
		search(arr, 10);
	}

}
