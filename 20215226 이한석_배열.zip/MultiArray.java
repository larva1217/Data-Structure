
public class MultiArray {
	static void printArray(int arr[][]) {
		for(int i=0; i<arr.length; i++) {
			for(int j=0; j<arr[i].length; j++) {
				System.out.printf("%3d ", arr[i][j]);
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int m=4;
		int n=5;
		int arr[][] = new int[m][n];
		int count =0; 
		for(int i=0; i<arr.length-1; i++) {
			for(int j=0; j<arr[i].length-1; j++) {
				count = count+1;
				arr[i][j] = count;
				arr[m-1][j]=count+arr[m-1][j];
				arr[i][n-1]=count+arr[i][n-1];
			}
		}
		printArray(arr);
		
	}

}
