public class ArraySwitch {

	public static void main(String[] args) {
		int x=3; 
		int y=5;
		int tmp=0;
		tmp=x;
		x=y;
		y=tmp;
		System.out.println("x값 = " + x);
		System.out.println("y값 = " + y);
		
		
		int[] arr = {1,2,3,4};
		int[] brr = {5,6,7,8,9};
		int[] tmp0;
		tmp0=arr;
		arr=brr;
		brr=tmp0;
		for(int i=0; i<arr.length; i++) {
			System.out.print(arr[i]);
		}
		System.out.println();
		for(int i=0; i<brr.length; i++) {
			System.out.print(brr[i]);
		}
	}

}
