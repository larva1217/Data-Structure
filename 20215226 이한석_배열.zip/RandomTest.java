import java.util.Random;
import java.util.Scanner;
import java.util.Date;

public class RandomTest {
	public static void main(String[] args) {
		int N;
		int[] myNumber;
		Scanner reader = new Scanner(System.in); // Reading from System.in
		System.out.print("Enter a number: ");
		N = reader.nextInt(); // Scans the next token of the input as an int.
		System.out.println("Number :" + N);
		myNumber = new int[N];
		Random random = new Random();
		for (int i = 0, n = myNumber.length; i < n; i++) {
			myNumber[i] = random.nextInt(n);
			System.out.print(" " + myNumber[i]);
		}
		long start = System.currentTimeMillis();
		for(int i=0; i<myNumber.length; i++) {
			if(myNumber[i]>myNumber[i+1]) {
				int tmp=myNumber[i];
				myNumber[i] = myNumber[i+1];
				myNumber[i+1] = tmp;
			}
			long end = System.currentTimeMillis();
			long diff = end-start;
			System.out.println(diff);
		}
		
}
}