import java.util.Arrays;
//컴파일러에게 클래스가 속한 Arrays패키지를 선언
public class Merge {
    public static void main(String[] args) {
        int arr1[] = {1, 2, 3, 6, 7, 8, 9, 14, 16}; // run1
        int arr2[] = {4, 5, 10, 13}; // run2

        Arrays.sort(arr1); //Arrays페키지에 있는 sort 을 사용하여
        Arrays.sort(arr2); // 배열 오름 차순으로 정렬

        System.out.print("run1 :");
        for(int i = 0; i < arr1.length; i++) //arr1 배열의 길이 만큼 i++ 해서
        {
            System.out.print(" " + arr1[i]); //arr1 이자 run1 을 출력
        }
        System.out.println();

        System.out.print("run2 :");
        for(int i = 0; i < arr2.length; i++) //arr2 배열의 길이 만큼 i++ 해서
        {
            System.out.print(" " + arr2[i]); //arr2 이자 run2 을 출력
        }
        System.out.println();

        int run3 = arr1.length + arr2.length; //run3 에 run1 + run2 의 배열의 길이를 더한다.
        int arr3[] = new int[run3]; //arr3[] 에 run3을 선언

        int i = 0, j = 0, k = 0; //run1, run2, run3을 비교 하기 위해 변수 선언

        //run1 과 run2를 비교하여 run3저장
        while(i < arr1.length && j < arr2.length)
        {
            if(arr1[i] < arr2[j])
            {
                arr3[k++] = arr1[i++];
            }else if(arr1[i] > arr2[j])
            {
                arr3[k++] = arr2[j++];
            }else
            {
                arr3[k++] = arr1[i++];
                j++;
            }
        }

        // run1에 남은 원소들을 복사
        while(i < arr1.length)
        {
            arr3[k++] = arr1[i++];
        }

        // run2에 남은 원소들을 복사
        while(j < arr2.length)
        {
            arr3[k++] = arr2[j++];
        }

        // 합병된 배열 출력
        System.out.print("run3 :");
        for(int m = 0; m < run3; m++)
        {
            System.out.print(" " + arr3[m]);
        }
    }
}