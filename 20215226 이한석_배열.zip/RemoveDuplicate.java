public class RemoveDuplicate {

	static void removeDuplicate(int arr[], int n) {
		int count=0; 
		for(int i=0; i<n; i++) {
			if(i==0||arr[i] != arr[i-1]) {
				arr[count]=arr[i];
				count++;
			}
		}
		while(count<n) {
			arr[count]=0;
			count++;
		}
	}
	public static void main(String[] args) {
		int arr[] = {10,20,20,30,30,40,50,50};
		int n = arr.length;
		removeDuplicate(arr,n);
		System.out.println("Array after removing duplicates : ");
        for(int i = 0; i < n; i++)
        {
            System.out.print(arr[i] + " ");
        }
		
	}

}
