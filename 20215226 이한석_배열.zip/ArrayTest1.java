
public class ArrayTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {20,30,40,10,5,2,60,73};
		for(int i:arr) {
			System.out.println(" " + i);
		}
		System.out.println();
	
	
	for(int i=0; i<arr.length; i++) {
		System.out.print(" "+arr[i]);
	}
	System.out.println();
	}

}
