
public class Max {
	
	public static int maximum(int fdata[]) {
		int i, fmax;
		fmax = fdata[0];
		for(i=0; i<fdata.length; i++) {
			if(fdata[i]>fmax) {
				fmax = fdata[i];
			}
		}
		return fmax;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int data[] = new int[100];
		int i,max;
		for(i=0; i<100; i++) {
			data[i] = (int)Math.random()*999;
		}
		max = maximum(data);
		System.out.println("Max : " + max);
	}

}
