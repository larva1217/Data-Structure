
public class ArrayTest {
	public static void printArr(int[] arr) {
		System.out.print("[");
		for(int i=0; i<arr.length; i++) {
			if(i !=arr.length-1) {
				System.out.print(arr[i] +",");
			}
			else {
				System.out.print(arr[i] + "]");
			}
		}
		System.out.println();
	}
	
	public static void ShiftArray(int arr[]) {
		int last = arr[arr.length-1];
		for(int i=arr.length-1; i>0; i--) {
			arr[i]=arr[i-1];
		}
		arr[0]=last;
	}
	
	public static void ShiftArray(int arr[],int n) {
		int[] last = new int[n];
		for(int i=0; i<n; i++) {
			last[i]=arr[arr.length-n+i];
		}
		for(int i=arr.length-1; i>=n; i--) {
			arr[i] = arr[i-n];
		}
		for(int i=0; i<last.length; i++) {
			arr[i]= last[i];
		}
	}
	
	public static void reverseArray(int arr[]) {
		int tmp;
		for(int i=0; i<arr.length/2; i++) {
			tmp=arr[i];
			arr[i]=arr[arr.length-1-i];
			arr[arr.length-1-i]=tmp;
		}
	}
	
	public static void InsertArray(int arr[],int index, int num) {
		for(int i=arr.length-1; i>index; i--) {
			arr[i] = arr[i-1];
		}
		arr[index]=num;
	}
	
	public static void delArray(int[] arr, int index) {
		for(int i=index; i<arr.length-1; i++) {
			arr[i]=arr[i+1];
		}
		arr[arr.length-1]=0;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {6,3,1,9,7,2};
		printArr(arr);
		System.out.println("ShiftArray");
		ShiftArray(arr);
		printArr(arr);
		System.out.println();
		
		System.out.println("ShiftArray 3");
		ShiftArray(arr, 3);
		printArr(arr);
		System.out.println();
		
		System.out.println("reverseArray");
		reverseArray(arr);
		printArr(arr);
		System.out.println();
		
		System.out.println("insertArray 2 6");
		InsertArray(arr,2,6);
		printArr(arr);
		System.out.println();
		
		System.out.println("delArray");
		delArray(arr,2);
		printArr(arr);
		System.out.println();
		
		
	}

}
