

interface Queue{
	boolean isEmpty();
	void enqueue(Object x);
	Object dequeue();
	Object peek();
}

class ArrayQueue implements Queue{
	Object[] q;
	int front, rear, qSize;
	public ArrayQueue() {
		q=new Object[10];
		front=0;
		rear=0; 
		qSize=0;
	}
	public boolean isEmpty() {
		return front==rear;
	}
	public void enqueue(Object x) {
		if((rear+1)%q.length==front) {
			reSizeQ(q.length*2);
		}
		rear=(rear+1)%q.length;
		q[rear]=x;
		qSize++;
	}
	public void reSizeQ(int newSize) {
		Object[] tmpQ = new Object[newSize];
		for(int i=1, j=front+1; i<qSize+1; i++,j++) {
			tmpQ[i]=q[j%q.length];
		}
		front=0; 
		rear=qSize;
		q=tmpQ;
	}
	public Object dequeue() {
		Object tmpItem;
		if(isEmpty()) { return -1; }
		front=(front+1)%q.length;
		tmpItem=q[front];
		q[front]=null;
		qSize--;
		return tmpItem;
	}
	public Object peek() {
		return q[(front+1)%q.length];
	}
}

public class ArrayQueueMain {
	public static void main(String[] args) {
		System.out.println("Hello Java");
		ArrayQueue aq1 = new ArrayQueue();
		aq1.enqueue(10);
		aq1.enqueue(20);
		aq1.enqueue("Kim");
		System.out.println(aq1.dequeue());
		System.out.println(aq1.peek());
	}
	
}
