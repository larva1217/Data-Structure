
import java.util.Queue;
import java.util.LinkedList;
public class FibQ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello Java");
		int n=10;
		int f0,f1,f2;
		Queue<Integer> q1 = new LinkedList<>();
		q1.add(1);
		q1.add(1);
		for(int i=2; i<=n; i++) {
			//q1.add(q1.remove()+q1.peek());
			f0=q1.remove();
			f1=q1.peek();
			f2=f1+f0;
			q1.add(f2);
		}
		System.out.println(q1.peek());
	}

}
