
import java.util.Queue;
import java.util.LinkedList;

class Student{
	int id;
	String name;
	public Student(int id1, String name1) {
		id=id1;
		name=name1;
	}
}
public class UtilQueueMain {
	public static void main(String[] args) {
		System.out.println("Hello Java");
		Queue<Integer> q1 = new LinkedList<Integer>();
		q1.add(10);
//		System.out.println(q1.remove());
		System.out.println(q1.poll());
		Queue<String> q2 = new LinkedList<String>();
		q2.add("Kim");
		System.out.println(q2.peek());
		Queue<Student> q3 = new LinkedList<Student>();
		Student s1 = new Student(1,"Kim");
		q3.add(s1);
		s1=new Student(2,"Lee");
		q3.add(s1);
		System.out.println("size="+q3.size());
		Student tmpS = q3.poll();
		System.out.println(tmpS.id+" "+tmpS.name);
	}

}
