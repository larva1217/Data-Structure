

interface Queue{
	boolean isEmpty();
	void enqueue(Object x);
	Object dequeue();
	Object peek();
}

class Node{
	Object data;
	Node link;
	public Node(Object x) {
		data=x;
		link=null;
	}
}

class LinkQueue implements Queue{
	Node front, rear;
	int qSize;
	public LinkQueue(){
		front=rear=null;
		qSize=0;
	}
	public boolean isEmpty() {
//		if(front==null) {
//			return true;
//		}
//		else {
//			return false;
//		}
		return (front==null);
	}
	public void enqueue(Object x) {
		Node newNode = new Node(x);
		if(isEmpty()) {
			front=newNode;
			rear=newNode;
		}else {
			rear.link=newNode;
			rear=newNode;
		}
		qSize++;
	}
	public Object dequeue() {
		if(isEmpty()) {
			return -1;
		}else {
			Object tmpItem=front.data;
			front=front.link;
			qSize--;
			return tmpItem;
		}
	}
	public Object peek() {
		return front.data;
	}
}

public class LinkQueueMain {
	public static void main(String[] args) {
		System.out.println("Hello Java");
		ArrayQueue lq1 = new ArrayQueue();
		lq1.enqueue(10);
		lq1.enqueue(20);
		lq1.enqueue("Kim");
		System.out.println(lq1.dequeue());
		System.out.println(lq1.dequeue());
		System.out.println(lq1.peek());
	}
	
}
