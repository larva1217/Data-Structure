import java.util.Stack;


class Node {
    Object data;
    Node link;

    public Node(Object x) {
        data = x;
        link = null;
    }
}



class LinkStack implements Stack1 {
    public Node top;

    public boolean isEmpty() {
        return top == null;
    }

    public void push(Object x) {
        Node newNode = new Node(x);
        newNode.link = top;
        top = newNode;
    }

    public Object pop() {
        if (isEmpty()) {
            return null;
        }
        Object item = top.data;
        top = top.link;
        return item;
    }

    public Object peek() {
        return top.data;
    }
}



public class LinkStackMain {
    public static void main(String[] args) {
        LinkStack stack1 = new LinkStack();

        stack1.push("Kim");
        stack1.push("Lee");
        stack1.push("Park");
        stack1.push("Song");

        System.out.println("선두 원소: " + stack1.peek());
        System.out.println("pop()으로 원소 출력:");

        while (!stack1.isEmpty()) {
            System.out.println(stack1.pop());
        }

        // 스택 stack3를 만들고 내가 만든 클래스 <id, name>으로 생성한 객체를 push하기
        LinkStack stack3 = new LinkStack();

        stack3.push(new MyClass(1, "Kim"));
        stack3.push(new MyClass(2, "Lee"));
        stack3.push(new MyClass(3, "Pack"));
        stack3.push(new MyClass(4, "Joo"));
        stack3.push(new MyClass(5, "Choi"));
        stack3.push(new MyClass(6, "Moon"));
        stack3.push(new MyClass(7, "Go"));
        stack3.push(new MyClass(8, "You"));
        stack3.push(new MyClass(9, "Soo"));
        stack3.push(new MyClass(10, "Wow"));

        // 이하 생략
    }
}



class MyClass {
    int id;
    String name;

    public MyClass(int id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public String toString() {
        return "<" + id + ", \"" + name + "\">";
    }
}