

import java.util.Stack;

interface Stack1 {
    boolean isEmpty();
    void push(Object x);
    Object pop();
    Object peek();
}

class Student {
    int id;
    String name;

    public Student(int id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public String toString() {
        return "<" + id + ", \"" + name + "\">";
    }
}
class Node {
    Object data;
    Node link;

    public Node(Object x) {
        data = x;
        link = null;
    }
}

class LinkStack implements Stack1 {
    private Object[] array;
    private int top;
    private static final int MAX_SIZE = 10; // 최대 크기

    public LinkStack() {
        array = new Object[MAX_SIZE];
        top = -1; // 스택이 비어있는 경우를 나타내기 위해 -1로 초기화
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public boolean isFull() {
        return top == MAX_SIZE - 1;
    }

    public void push(Object x) {
        if (isFull()) {
            System.out.println("Stack is full. Creating temporary stack to move elements.");

            // 임시 스택을 생성하고 요소를 옮깁니다.
            LinkStack tempStack = new LinkStack();
            while (!isEmpty()) {
                tempStack.push(pop());
            }

            // 스택이 비어있는지 다시 확인합니다.
            if (isEmpty()) {
                System.out.println("Current stack is empty.");
            }

            // 새로운 요소를 추가합니다.
            array[++top] = x;

            // 임시 스택의 요소를 현재 스택으로 복사합니다.
            while (!tempStack.isEmpty() && !isFull()) {
                array[++top] = tempStack.pop();
            }
        } else {
            array[++top] = x;
        }
    }


    public Object pop() {
        if (isEmpty()) {
            return null;
        }
        return array[top--];
    }

    public Object peek() {
        if (isEmpty()) {
            return null;
        }
        return array[top];
    }
}


public class LinkStackMain {
    public static void main(String[] args) {
        LinkStack stack1 = new LinkStack();
        stack1.push("Kim");
        stack1.push("Lee");
        stack1.push("Park");
        stack1.push("Song");
        stack1.push("Sung");
        stack1.push("Kang");


        System.out.println("선두 원소: " + stack1.peek());

        System.out.println("pop()으로 원소 출력:");
        while (!stack1.isEmpty()) {
            System.out.println(stack1.pop());
        }

        // 스택 stack3를 만들고 내가 만든 클래스 <id, name>으로 생성한 객체를 push하기
        LinkStack stack3 = new LinkStack();
        stack3.push(new Student(1, "Kim"));
        stack3.push(new Student(2, "Lee"));
        stack3.push(new Student(3, "Pack"));
        stack3.push(new Student(4, "Joo"));
        stack3.push(new Student(5, "Choi"));
        stack3.push(new Student(6, "Moon"));
        stack3.push(new Student(7, "Go"));
        stack3.push(new Student(8, "You"));
        stack3.push(new Student(9, "Soo"));
        stack3.push(new Student(10, "Wow"));

        if (!stack3.isEmpty()) {
            System.out.println("선두 원소: " + stack3.peek());
            // 이하 생략
        }
    }
}



