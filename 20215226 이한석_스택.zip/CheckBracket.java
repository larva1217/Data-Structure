
import java.util.Stack;

public class CheckBracket {

public static boolean isValid(String s) {

char[] s2=s.toCharArray();

Stack<Character> stack1=new Stack<>();

for (char c:s2) {

if(c=='(') {stack1.push(c);}

else if(c=='{') {stack1.push(c);}

else if(c=='[') {stack1.push(c);}

else if(c==')') {

if(stack1.empty()) {

return false;

}else {

if(stack1.pop()=='(') {

System.out.println("소괄호 짝이 맞음");

}

else {

System.out.println("에러");

}

}

}

else if(c=='}') {

if(stack1.empty()) {

return false;

}else {

if(stack1.pop()=='{') {

System.out.println("중괄호 짝이 맞음");

}

else {

System.out.println("에러");

}

}

}

else if(c==']') {

if(stack1.empty()) {

return false;

}else {

if(stack1.pop()=='[') {

System.out.println("대괄호 짝이 맞음");

}

else {

System.out.println("에러");

}

}

}

}

if(!stack1.empty()) {

return false;

}

return true;

}

public static void main(String[] args) {

System.out.println("20235202 안정우");

String s1="(((a)b))";

String s2="{{{a}b}}";

String s3="[[[a]b]]";

String s4="({[a]b})";

System.out.println(isValid(s1));

System.out.println(isValid(s2));

System.out.println(isValid(s3));

System.out.println(isValid(s4));

}

}

