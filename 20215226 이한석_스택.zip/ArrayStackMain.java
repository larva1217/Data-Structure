

interface Stack{
	boolean isEmpty();
	void push(Object x);
	Object pop();
	//void remove();
	Object peek();
}

class ArrayStack implements Stack{
	int top;
	Object[] itemArray;
	int stackSize;
	
	public ArrayStack() {
		stackSize=100;
		itemArray = new Object[stackSize];
		top=1;
	}
	public boolean isEmpty() {
		return top==-1;
	}
	public void push(Object x) {
		if(top==stackSize-1) {
			stackFull();
		}
		top=top+1;
		itemArray[top]=x;
	}
	public void stackFull() {
		stackSize=stackSize+increment;
		Object[] tmpArray= new Object[stackSize];

		for(int i=0;i<=top;i++) {

			tmpArray[i]=itemArray[i];

		}

		itemArray=tmpArray;


		}
	}
	public Object pop() {
		if(isEmpty()) {
			return null;
		}
		Object y=itemArray[top];
		top=top-1;
		return y;
	}
	//void remove();
	public Object peek() {
		if(isEmpty()) {
			return null;
		}else {
			return itemArray[top];
		}
	}
	public void delete() {
		while(!isEmpty()) {
			pop();
		}
	}
}

public class ArrayStackMain {
	public static void main(String[] args) {
		ArrayStack stack1 = new ArrayStack();
		stack1.push(10);
		stack1.push("Kim");
		System.out.println(stack1.pop());
	}
 }
