
import java.util.Stack;

class Student{
	int id;
	String name;
	public Student(int id, String name) {
		this.id=id;
		this.name=name;
	}
	public String toString() {
		return id+" "+name;
	}
}

public class UtilStackMain {
	public static void main(String[] args) {
		Stack<String> stack1 = new Stack<>();
		stack1.push("Kim");
		stack1.push("Lee");
		System.out.println(stack1.pop());
		Stack<Integer> stack2 = new Stack<>();
		stack2.push(10);
		stack2.push(20);
		System.out.println(stack2.pop());
		
		Stack<Student> stack3 = new Stack<>();
		Student s1 = new Student(1,"Kim");
		stack3.push(s1);
		Student s2 = new Student(1,"Kim");
		stack3.push(s2);
		System.out.println(stack3.pop());
	}
}
